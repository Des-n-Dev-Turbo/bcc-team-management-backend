import type { MiddlewareHandler, Next } from "hono";
import { Table } from "@/constants/common.ts";
import { ERROR_CODES } from "@/constants/error-codes.ts";
import { getSupabase } from "@/lib/supabase.ts";
import { uuidSchema } from "@/schemas/common.schema.ts";
import {
  type AppContext,
  hasRequiredRole,
  Role,
  YearAccessStatus,
} from "@/types";
import { AppError } from "@/utils/error.ts";

export const requireYearAccess: MiddlewareHandler<AppContext> = async (
  c,
  next: Next,
) => {
  const profile = c.get("profile");

  if (hasRequiredRole(profile.global_role, Role.Admin)) {
    await next();
    return;
  }

  const yearId = c.req.query("yearId") ?? c.req.param("yearId") ?? null;

  if (!yearId) {
    throw new AppError(
      "Year ID is required",
      ERROR_CODES.VALIDATION_ERROR,
      400,
    );
  }

  const validYearId = uuidSchema.safeParse(yearId);

  if (!validYearId.success) {
    throw new AppError(
      "Invalid year ID format",
      ERROR_CODES.VALIDATION_ERROR,
      400,
    );
  }

  const db = getSupabase();

  const { data: yearAccessData, error: yearAccessError } = await db
    .from(Table.YearAccess)
    .select()
    .eq("user_id", profile.id)
    .eq("year_id", yearId)
    .eq("status", YearAccessStatus.APPROVED)
    .maybeSingle();

  if (yearAccessError) {
    throw new AppError(
      "Failed to check year access",
      ERROR_CODES.YEAR_ACCESS_CHECK_FAILED,
      500,
    );
  }

  if (!yearAccessData) {
    throw new AppError(
      "Forbidden: You do not have access to this year",
      ERROR_CODES.FORBIDDEN,
      403,
    );
  }

  c.set("yearAccess", {
    id: yearAccessData.id,
    year_id: yearAccessData.year_id,
    user_id: yearAccessData.user_id,
    status: yearAccessData.status,
  });

  await next();
};
